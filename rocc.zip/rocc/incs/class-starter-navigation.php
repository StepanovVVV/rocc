<?php

// class Starter_Navigation extends Walker_Nav_Menu {

//     public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {
//         $menu_item = $data_object;

//         $t = isset( $args->item_spacing ) && 'discard' === $args->item_spacing ? '' : "\t";
//         $n = isset( $args->item_spacing ) && 'discard' === $args->item_spacing ? '' : "\n";
//         $indent = $depth ? str_repeat( $t, $depth ) : '';

//         $classes = empty( $menu_item->classes ) ? array() : (array) $menu_item->classes;
//         $classes[] = 'menu-item-' . $menu_item->ID;
//         $classes[] = 'header__item'; // Ваш кастомный класс

//         $has_children = !empty($menu_item->classes) && in_array('menu-item-has-children', $menu_item->classes);

//         if ($has_children) {
//             $classes[] = $depth === 0 ? 'dropdown' : 'dropstart';
//         }

//         $class_names = implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $menu_item, $args, $depth ) );
//         $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

//         $id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $menu_item->ID, $menu_item, $args, $depth );
//         $id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

//         $output .= $indent . '<li' . $id . $class_names . '>';

//         $atts = array();
//         $atts['title']  = ! empty( $menu_item->attr_title ) ? $menu_item->attr_title : '';
//         $atts['target'] = ! empty( $menu_item->target ) ? $menu_item->target : '';
//         $atts['rel'] = $menu_item->target === '_blank' && empty( $menu_item->xfn ) ? 'noopener' : $menu_item->xfn;

//         if ( ! empty( $menu_item->url ) ) {
//             if ( get_privacy_policy_url() === $menu_item->url ) {
//                 $atts['rel'] = empty( $atts['rel'] ) ? 'privacy-policy' : $atts['rel'] . ' privacy-policy';
//             }

//             $atts['href'] = $menu_item->url;
//         } else {
//             $atts['href'] = '';
//         }

//         $atts['aria-current'] = $menu_item->current ? 'page' : '';

//         $active_class = $menu_item->current ? 'active' : '';
//         $active_parent_class = $menu_item->current_item_ancestor ? ' active' : '';

//         if ($has_children) {
//             $atts['class'] = $depth === 0 ? 'header__link dropdown-toggle ' . $active_class . $active_parent_class : 'dropdown-item dropdown-toggle ' . $active_class . $active_parent_class;
//             $atts['data-bs-toggle'] = 'dropdown';
//             $atts['data-bs-auto-close'] = 'outside';
//             $atts['aria-expanded'] = 'false';

//             // Открываем <div> для обертки кнопки и ссылки
//             $output .= '<div class="menu-item-wrapper">';

//             // Добавляем кнопку для открытия подменю
//             $output .= '<button class="submenu-toggle" aria-expanded="false" data-bs-toggle="dropdown" data-bs-auto-close="outside">';
//             $output .= '<span class="submenu-toggle-icon"></span>';
//             $output .= '</button>';
//         } else {
//             $atts['href'] = !empty($menu_item->url) ? $menu_item->url : '#';
//             if ($depth > 0) {
//                 $atts['class'] = 'dropdown-item ' . $active_class . $active_parent_class;
//             } else {
//                 $atts['class'] = 'header__link ' . $active_class . $active_parent_class;
//             }
//         }

//         $atts = apply_filters( 'nav_menu_link_attributes', $atts, $menu_item, $args, $depth );

//         $attributes = '';
//         foreach ( $atts as $attr => $value ) {
//             if ( is_scalar( $value ) && '' !== $value && false !== $value ) {
//                 $value = $attr === 'href' ? esc_url( $value ) : esc_attr( $value );
//                 $attributes .= ' ' . $attr . '="' . $value . '"';
//             }
//         }

//         $title = apply_filters( 'the_title', $menu_item->title, $menu_item->ID );
//         $title = apply_filters( 'nav_menu_item_title', $title, $menu_item, $args, $depth );

//         $item_output = '';
        
//         if (is_object($args)) {
//             $item_output  = $args->before;

//             // Если элемент имеет дочерние элементы, обернем и ссылку в div
//             if ($has_children) {
//                 // Вставляем ссылку
//                 $item_output .= '<a' . $attributes . '>';
//                 $item_output .= $args->link_before . $title . $args->link_after;
//                 $item_output .= '</a>';
                
//                 // Закрываем div
//                 $item_output .= '</div>';
//             } else {
//                 // Для элементов без подменю просто выводим ссылку
//                 $item_output .= '<a' . $attributes . '>';
//                 $item_output .= $args->link_before . $title . $args->link_after;
//                 $item_output .= '</a>';
//             }

//             $item_output .= $args->after;
//         }

//         $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $menu_item, $depth, $args );
//     }

//     public function start_lvl( &$output, $depth = 0, $args = null ) {
//         $t = isset( $args->item_spacing ) && 'discard' === $args->item_spacing ? '' : "\t";
//         $n = isset( $args->item_spacing ) && 'discard' === $args->item_spacing ? '' : "\n";
//         $indent = str_repeat( $t, $depth );

//         $classes = array( 'dropdown-menu dropdown-menu-end' );

//         $class_names = implode( ' ', apply_filters( 'nav_menu_submenu_css_class', $classes, $args, $depth ) );
//         $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

//         $output .= "{$n}{$indent}<ul$class_names>{$n}";
//     }
// }


class Starter_Navigation extends Walker_Nav_Menu {

    public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {
        $menu_item = $data_object;

        $t = isset( $args->item_spacing ) && 'discard' === $args->item_spacing ? '' : "\t";
        $n = isset( $args->item_spacing ) && 'discard' === $args->item_spacing ? '' : "\n";
        $indent = $depth ? str_repeat( $t, $depth ) : '';

        $classes = empty( $menu_item->classes ) ? array() : (array) $menu_item->classes;
        $classes[] = 'menu-item-' . $menu_item->ID;
        $classes[] = 'header__item'; // Ваш кастомный класс

        $has_children = !empty($menu_item->classes) && in_array('menu-item-has-children', $menu_item->classes);

        if ($has_children) {
            $classes[] = $depth === 0 ? 'dropdown' : 'dropstart';
        }

        $class_names = implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $menu_item, $args, $depth ) );
        $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

        $id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $menu_item->ID, $menu_item, $args, $depth );
        $id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

        $output .= $indent . '<li' . $id . $class_names . '>';

        $atts = array();
        $atts['title']  = ! empty( $menu_item->attr_title ) ? $menu_item->attr_title : '';
        $atts['target'] = ! empty( $menu_item->target ) ? $menu_item->target : '';
        $atts['rel'] = $menu_item->target === '_blank' && empty( $menu_item->xfn ) ? 'noopener' : $menu_item->xfn;

        if ( ! empty( $menu_item->url ) ) {
            if ( get_privacy_policy_url() === $menu_item->url ) {
                $atts['rel'] = empty( $atts['rel'] ) ? 'privacy-policy' : $atts['rel'] . ' privacy-policy';
            }

            $atts['href'] = $menu_item->url;
        } else {
            $atts['href'] = '';
        }

        $atts['aria-current'] = $menu_item->current ? 'page' : '';

        $active_class = $menu_item->current ? 'active' : '';
        $active_parent_class = $menu_item->current_item_ancestor ? ' active' : '';

        if ($has_children) {
            $atts['class'] = $depth === 0 ? 'header__link dropdown-toggle ' . $active_class . $active_parent_class : 'dropdown-item dropdown-toggle ' . $active_class . $active_parent_class;
            $atts['data-bs-toggle'] = 'dropdown';
            $atts['data-bs-auto-close'] = 'outside';
            $atts['aria-expanded'] = 'false';

            // Открываем <div> для обертки кнопки и ссылки
            $output .= '<div class="menu-item-wrapper">';

            // Добавляем кнопку для открытия подменю
            $output .= '<button class="submenu-toggle" aria-expanded="false" data-bs-toggle="dropdown" data-bs-auto-close="outside">';
            $output .= '<span class="submenu-toggle-icon"></span>';
            $output .= '</button>';
        } else {
            $atts['href'] = !empty($menu_item->url) ? $menu_item->url : '#';
            if ($depth > 0) {
                $atts['class'] = 'dropdown-item ' . $active_class . $active_parent_class;
            } else {
                $atts['class'] = 'header__link ' . $active_class . $active_parent_class;
            }
        }

        $atts = apply_filters( 'nav_menu_link_attributes', $atts, $menu_item, $args, $depth );

        $attributes = '';
        foreach ( $atts as $attr => $value ) {
            if ( is_scalar( $value ) && '' !== $value && false !== $value ) {
                $value = $attr === 'href' ? esc_url( $value ) : esc_attr( $value );
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $title = apply_filters( 'the_title', $menu_item->title, $menu_item->ID );
        $title = apply_filters( 'nav_menu_item_title', $title, $menu_item, $args, $depth );

        $item_output = '';
        
        if (is_object($args)) {
            $item_output  = $args->before;

            // Если элемент имеет дочерние элементы, обернем и ссылку в div
            if ($has_children) {
                // Вставляем ссылку с <span> внутри
                $item_output .= '<a' . $attributes . '>';
                $item_output .= $args->link_before . $title . '<div class="submenu-toggle-desk"><span class="submenu-toggle-icon"></span></div>' . $args->link_after;
                $item_output .= '</a>';
                
                // Закрываем div
                $item_output .= '</div>';
            } else {
                // Для элементов без подменю просто выводим ссылку
                $item_output .= '<a' . $attributes . '>';
                $item_output .= $args->link_before . $title . $args->link_after;
                $item_output .= '</a>';
            }

            $item_output .= $args->after;
        }

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $menu_item, $depth, $args );
    }

    public function start_lvl( &$output, $depth = 0, $args = null ) {
        $t = isset( $args->item_spacing ) && 'discard' === $args->item_spacing ? '' : "\t";
        $n = isset( $args->item_spacing ) && 'discard' === $args->item_spacing ? '' : "\n";
        $indent = str_repeat( $t, $depth );
    
        // Массив классов для уровня подменю
        $classes = array( 'dropdown-menu' );
    
        // Добавляем класс 'dropdown-menu-end' только для первого уровня (где $depth === 0)
        if ( $depth === 0 ) {
            $classes[] = 'dropdown-menu-end';
        }
    
        // Применяем фильтры и формируем строку классов
        $class_names = implode( ' ', apply_filters( 'nav_menu_submenu_css_class', $classes, $args, $depth ) );
        $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';
    
        // Выводим начало уровня подменю
        $output .= "{$n}{$indent}<ul$class_names>{$n}";
    }
    
}
