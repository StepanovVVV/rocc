<?php
/**
 * Header
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo( 'charset' ) ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> class="hidden body-wrapper" id="content">
    <?php wp_body_open(); ?>
    <header class="header">
        <div class="header__container grid-container">
            <div class="header__logo">
                <a href="<?php echo home_url( '/' ); ?>">
                    <?php
                    $custom_logo_id = get_theme_mod( 'custom_logo' );

                    if ( $custom_logo_id ) :
                        $logo_url = wp_get_attachment_image_src( $custom_logo_id, 'full' );

                        if ( $logo_url ) : ?>
                            <img src="<?php echo esc_url( $logo_url[0] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />
                        <?php endif; ?>
                    <?php else : ?>
                        <h1 class="header__title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>
                    <?php endif; ?>
                </a>
            </div>
            <div class="header__burger">
                <span></span>
            </div>
            <div class="header__menu">
                <?php if ( has_nav_menu( 'header-menu' ) ): ?>
                <nav class="header__nav">
                    <?php 
                        wp_nav_menu(array(
                            'theme_location' => 'header-menu',
                            'container' => false,
                            'menu_class' => 'header__items',
                            'walker' => new Starter_Navigation(),
                        ));
                    ?>
                    <div class="header__item">
                        <div class="header__socials">
                            <?php get_template_part('parts/socials-cfs'); // Social profiles ?>
                        </div>
                    </div>
                </nav>
                <?php endif; ?>
                <div class="header__overlay"></div>
            </div>
        </div>
    </header>