<?php
/**
 * Footer
 */
?>
<?php $home_page_id = get_option('page_on_front'); ?>
<footer class="footer">
        <div class="footer__container grid-container">
            <div class="grid-x grid-padding-x">
            <?php if ( $copyright = CFS()->get('copy_right', $home_page_id) ) : ?>
                <div class="cell small-12 medium-12 large-3">
                    <div class="footer__wrap">
                        <div class="footer__copy"><?php echo $copyright; ?></div>
                    </div>
                </div>
            <?php endif; ?>
                <div class="cell small-12 medium-12 large-5">
                    <div class="footer__wrap">
                        <nav class="footer__nav">
                            <ul class="footer__items">
                            <?php if ( $address = CFS()->get('address', $home_page_id) ) : ?>
                                <li class="footer__item">
                                    <?php 
                                        $encoded_address = urlencode($address);
                                        $google_maps_link = "https://www.google.com/maps/search/?api=1&query=$encoded_address";
                                    ?>
                                    <a href="<?php echo esc_url($google_maps_link); ?>" target="_blank" class="footer__link">
                                        <?php echo esc_html($address); ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if ( $phone = CFS()->get('phone', $home_page_id) ) :
                                $clean_phone = preg_replace('/\D+/', '', $phone);
                            ?>
                                <li class="footer__item">
                                    <a href="tel:<?php echo $clean_phone; ?>" class="footer__link"><?php echo esc_html($phone); ?></a>
                                </li>
                            <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="cell small-12 medium-6 large-1">
                    <div class="footer__wrap">
                        <div class="footer__socials">
                            <?php get_template_part('parts/socials-cfs'); // Social profiles ?>
                        </div>
                    </div>
                </div>
                <div class="cell small-12 medium-6 large-3">
                    <div class="footer__wrap">
                        <div class="footer__form">
                            <form action="<?php echo esc_url( get_template_directory_uri() . '/process_form.php' ); ?>" method="post" class="form">
                                <input type="email" id="email" name="email" required placeholder="Newsletter Subscribe" autocomplete="off" class="form__input">
                                <div class="form__btns">
                                    <button type="submit" class="form__btn">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/image/social/letter.svg" alt="Letter">
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Pop-up  -->
    <div id="popup" class="popup" style="display: none;">
        <div class="popup__container">
            <div class="popup__wrapper">
                <span class="popup__close">×</span>
                <div class="popup__content">
                    <h3 class="popup__title"><?php echo __('Contact us now', 'custom-theme'); ?></h3>
                    <p class="popup__info"><?php echo __('Our manager will contact you as soon as possible.', 'custom-theme'); ?></p>
                </div>
                <div class="popup__form">
                    <form action="<?php echo esc_url( get_template_directory_uri() . '/process_form.php' ); ?>" method="post" class="form">
                        <input type="text" id="name-2" name="name" placeholder="Name" required autocomplete="off" class="form__input">
                        <input type="tel" id="phone-2" name="phone" required placeholder="Phone Number" autocomplete="off" class="form__input phone">
                        <div class="form__btn btn">
                            <button type="submit" class="btn__wrap"><?php echo __('Subscribe', 'custom-theme'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Phones -->
    <?php 
        $icon_phone = CFS()->get('icon_phone', $home_page_id);
        $phone = CFS()->get('phone', $home_page_id);

        if ( !empty($icon_phone) || !empty($phone) ) :
    ?>
        <div class="phones">
            <?php 
                if ( !empty($icon_phone) ) :
                    $icon_phone_url = wp_get_attachment_url($icon_phone);
                    $icon_phone_alt = get_post_meta($icon_phone, '_wp_attachment_image_alt', true);

                    if ( empty($icon_phone_alt) ) {
                        $icon_phone_alt = get_bloginfo('name');
                    }
            ?>
                <div class="phones__icon">
                    <img src="<?php echo esc_url($icon_phone_url); ?>" alt="<?php echo esc_attr($icon_phone_alt); ?>">
                </div>
            <?php endif; ?>
            <div class="phones__wrap">
                <?php 
                    if ( !empty($phone) ) :
                        $clean_phone = preg_replace('/\D+/', '', $phone);
                ?>
                    <a href="tel:<?php echo esc_attr($clean_phone); ?>" class="phones__link"><?php echo esc_html($phone); ?></a>
                <?php endif; ?>
            </div>
            <div class="phones__socials">
                <?php get_template_part('parts/socials-cfs'); ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Scroll up btn -->
    <?php 
        $scroll_up_id = CFS()->get('icon_scroll_up', $home_page_id);

        if ( !empty($scroll_up_id) ) :
            $scroll_up_url = wp_get_attachment_url($scroll_up_id);
            $scroll_up_alt = get_post_meta($scroll_up_id, '_wp_attachment_image_alt', true);

            if ( empty($scroll_up_alt) ) {
                $scroll_up_alt = get_bloginfo('name');
            }
        ?>
            <div class="scroll-up">
                <div class="scroll-up__icon">
                    <img src="<?php echo esc_url($scroll_up_url); ?>" alt="<?php echo esc_attr($scroll_up_alt); ?>">
                </div>
            </div>
        <?php endif; ?>

    <?php wp_footer(); ?>

</body>

</html>