<?php
/**
 * Template Name: Thank you page
 */

get_header('another'); ?>

<main class="main-wrapper main-top">
    <section class="thanks">
        <div class="thanks__container grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="thanks__wrap">
                        <h2 class="thanks__title"><?php _e('Thank you for your submission!', 'default'); ?></h2>
                        <p class="thanks__info">
                            <?php _e('We have successfully received your information. Our specialists will contact you shortly
                            for further steps. We appreciate your interest and will try to respond as soon as
                            possible!', 'default'); ?>
                        </p>
                        <div class="thanks__btn btn">
                            <a href="<?php echo home_url( '/' ) ?>" class="btn__wrap"><?php _e('Back to Home', 'default'); ?></a>
                        </div>
                        <h3 class="thanks__title-2"><?php _e("What's the next step?", 'default'); ?></h3>
                        <p class="thanks__info">
                            <?php _e('Our managers will verify your application and contact you with the details provided. You
                            can expect a call to the number you provided or an email to your email. We are ready to
                            help you with any questions and offer the best solutions!', 'default'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>