<?php
/**
 * Plugin Name: Contact Form Shortcode
 * Description: A simple plugin to add a contact form shortcode.
 */

// Register the shortcode to display the contact form
function contact_form_shortcode($atts) {
    // Retrieve settings values
    $description = get_option('contact_form_description', 'Form description here.');  // Default description if not set
    $button_text = get_option('contact_form_button_text', 'Submit');  // Default button text if not set
    $contact_title = get_option('contact_form_contact_title', 'Enter your contact information');  // New title for contact section

    // Output the form HTML
    ob_start(); // Start output buffering
    ?>
    <section class="contact-form">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell small-12 medium-6 large-8">
                    <div class="contact-form__wrap">
                        <div class="contact-form__info">
                            <?php echo wpautop($description); ?>
                        </div>
                    </div>
                </div>
                <div class="cell small-12 medium-6 large-4">
                    <div class="contact-form__wrap">
                        <h3 class="contact-form__title"><?php echo esc_html($contact_title); ?></h3> 
                        <form action="<?php echo esc_url( home_url( '/wp-content/themes/custom-theme/process_form.php' ) ); ?>" method="post" class="form contact-form__form">
                            <input type="text" id="name" name="name" placeholder="<?php echo __('Name', 'testdomain') ?>" required autocomplete="off" class="form__input">
                            <input type="tel" id="phone" name="phone" required placeholder="<?php echo __('Phone Number', 'testdomain') ?>" autocomplete="off" class="form__input phone">
                            <div class="form__btn btn">
                                <button type="submit" class="btn__wrap"><?php echo esc_html($button_text); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();  // Return the buffered content
}
add_shortcode('contact_form', 'contact_form_shortcode'); // [contact_form]

