<?php
add_action( 'customize_register', function ( WP_Customize_Manager $wp_customize ) {

    // Section for custom settings
    $wp_customize->add_section( 'custom_options_theme', array(
        'title'    => __( 'Contacts', 'default' ),
        'priority' => 10,
    ) );

    // Phone
    $wp_customize->add_setting( 'custom_phone', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'custom_phone', array(
        'label'   => __( 'Phone', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Address
    $wp_customize->add_setting( 'custom_address', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'custom_address', array(
        'label'   => __( 'Address name', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Address link
    $wp_customize->add_setting( 'custom_address_link', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ) );
    $wp_customize->add_control( 'custom_address_link', array(
        'label'   => __( 'Address link', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Google Maps API Key
    $wp_customize->add_section( 'google_maps_section', array(
        'title'    => __( 'Google Maps API', 'default' ),
        'priority' => 30,
    ) );

    $wp_customize->add_setting( 'google_maps_api_key', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'google_maps_api_key', array(
        'label'   => __( 'Google Maps API Key', 'default' ),
        'section' => 'google_maps_section',
        'type'    => 'text',
    ) );

    // Social media links
    $social_media_settings = [
        'custom_instagram' => __( 'Instagram Link', 'default' ),
        'custom_tiktok'    => __( 'TikTok Link', 'default' ),
        'custom_facebook'  => __( 'Facebook Link', 'default' ),
    ];
    
    foreach ( $social_media_settings as $setting_key => $label ) {
        $wp_customize->add_setting( $setting_key, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ) );
        $wp_customize->add_control( $setting_key, array(
            'label'   => $label,
            'section' => 'custom_options_theme',
        ) );
    }

    // Section for work hours
    $wp_customize->add_section( 'work_hours_section', array(
        'title'    => __( 'Work Hours', 'default' ),
        'priority' => 40,
    ) );

    // Title for work hours
    $wp_customize->add_setting( 'work_hours_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'work_hours_title', array(
        'label'   => __( 'Work Hours Title', 'default' ),
        'section' => 'work_hours_section',
    ) );

    // Work hours for weekdays
    $wp_customize->add_setting( 'work_hours_weekdays', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'work_hours_weekdays', array(
        'label'   => __( 'Work hours for weekdays', 'default' ),
        'section' => 'work_hours_section',
    ) );

    // Work hours for weekends
    $wp_customize->add_setting( 'work_hours_weekends', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'work_hours_weekends', array(
        'label'   => __( 'Work hours for weekends', 'default' ),
        'section' => 'work_hours_section',
    ) );

    // New Section for the additional text field
    $wp_customize->add_section( 'additional_text_section', array(
        'title'    => __( 'Additional Information', 'default' ),
        'priority' => 50,
    ) );

    // For additional information Copy
    $wp_customize->add_setting( 'additional_info_copy', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ) );
    $wp_customize->add_control( 'additional_info_copy', array(
        'label'   => __( 'Copyright', 'default' ),
        'section' => 'additional_text_section',
        'type'    => 'textarea',
    ) );
}, 10 );

// Get settings as an array
function custom_options_theme() {
    return array(
        'phone'               => get_theme_mod( 'custom_phone', '' ),
        'address_name'        => get_theme_mod( 'custom_address', '' ),
        'address_link'        => get_theme_mod( 'custom_address_link', '' ),
        'instagram'           => get_theme_mod( 'custom_instagram', '' ),
        'tiktok'              => get_theme_mod( 'custom_tiktok', '' ),
        'facebook'            => get_theme_mod( 'custom_facebook', '' ),
        // Section work hours
        'work_hours_title'    => get_theme_mod( 'work_hours_title', '' ),
        'work_hours_weekdays' => get_theme_mod( 'work_hours_weekdays', '' ),
        'work_hours_weekends' => get_theme_mod( 'work_hours_weekends', '' ),
        // Section additional information
        'additional_info_copy' => get_theme_mod( 'additional_info_copy', '' ),
    );
}

// using code in layout
/* 
    // Add function on page 
    <?php $custom_options_theme = custom_options_theme(); ?>

    <?php if ( ! empty( $custom_options_theme['phone'] ) ): ?>
        <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone'] ); ?>">
            <?php echo $custom_options_theme['phone']; ?>
        </a>
    <?php endif; ?>

    <?php if ( ! empty( $custom_options_theme['facebook'] ) ): ?>
        <li>
            <a href="<?php echo $custom_options_theme['facebook'] ?>"></a>
        </li>
    <?php endif; ?>
*/
?>

