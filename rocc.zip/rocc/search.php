<?php
/**
 * Search Results Template
 */
get_header(); ?>

	<div class="grid-container">
		<div class="grid-x grid-padding-x posts-list">
			<div class="cell small-12">
				<!-- BEGIN of search results -->
				<main class="main-content">
					<h1 class="page-title"><?php printf( __( 'Search Results for: %s', 'default' ), '<span>' . esc_html( get_search_query() ) . '</span>' ); ?></h1>
					
					<!-- Search form -->
					<?php get_search_form(); ?>

					<?php if ( have_posts() ) : ?>
						<?php while ( have_posts() ) : the_post(); ?>
							<?php get_template_part( 'parts/loop', 'post' ); // Post item ?>
						<?php endwhile; ?>

						<!-- Pagination -->
						<?php starter_pagination(); ?>
					<?php else: ?>
						<h3><?php _e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'default' ); ?></h3>
					<?php endif; ?>
				</main>
				<!-- END of search results -->
			</div>
		</div>
	</div>

<?php get_footer(); ?>
