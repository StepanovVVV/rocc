<?php
// We are adding a metabox
add_action( 'add_meta_boxes', 'add_slider_meta_box' );

function add_slider_meta_box() {
    add_meta_box(
        'slider_related_posts', // Identifier of the metabox
        __( 'Related Posts or Pages', 'default' ), // Metabox title
        'slider_meta_box_callback', // Callback function
        'slider', // For what type of post
        'side', // Location (side, normal)
        'high' // Priority
    );
}

// Callback function for metabox
function slider_meta_box_callback( $post ) {
    // Get the saved values
    $selected_post_id_1 = get_post_meta( $post->ID, '_slider_related_post_1', true );
    $button_text_1 = get_post_meta( $post->ID, '_slider_button_text_1', true ); 
    $open_in_new_tab_1 = get_post_meta( $post->ID, '_slider_open_in_new_tab_1', true ); 
    $button_type_1 = get_post_meta( $post->ID, '_slider_button_type_1', true );
    $external_url_1 = get_post_meta( $post->ID, '_slider_external_url_1', true );
    $selected_post_id_2 = get_post_meta( $post->ID, '_slider_related_post_2', true );
    $button_text_2 = get_post_meta( $post->ID, '_slider_button_text_2', true ); 
    $open_in_new_tab_2 = get_post_meta( $post->ID, '_slider_open_in_new_tab_2', true ); 
    $button_type_2 = get_post_meta( $post->ID, '_slider_button_type_2', true );
    $external_url_2 = get_post_meta( $post->ID, '_slider_external_url_2', true );

    // We execute a request to get all posts or pages
    $args = array(
        'post_type'   => array( 'post', 'page' ), 
        'post_status' => 'publish',
        'numberposts' => -1,
    );
    $posts = get_posts( $args );

    // Fields for the first button
    echo '<div style="display: flex; flex-direction: column;">';
    echo '<div class="slider-button-fields" style="display: inline-flex; align-items: center; flex-wrap: wrap; gap: 10px;">';
    // Button Type - Move First
    echo '<label for="slider_button_type_1">' . __( 'Button Type (Button 1):', 'custom-theme' ) . '</label>';
    echo '<select id="slider_button_type_1" name="slider_button_type_1" style="width: auto; display: inline-block;">
            <option value="internal" ' . selected( $button_type_1, 'internal', false ) . '>' . __( 'Internal', 'custom-theme' ) . '</option>
            <option value="external" ' . selected( $button_type_1, 'external', false ) . '>' . __( 'External', 'custom-theme' ) . '</option>
        </select>';
    // External Link Fields (External)
    echo '<div id="external_link_1_fields" class="' . ( 'internal' === $button_type_1 ? 'hidden' : '' ) . '" style="display: inline-block;">';
    echo '<label for="slider_related_post_1" style="margin-right: 10px;">' . __( 'Select a post or page:', 'custom-theme' ) . '</label>';
    echo '<select id="slider_related_post_1" name="slider_related_post_1" style="width: 100%;">';
    echo '<option value="">' . __( 'None', 'custom-theme' ) . '</option>';
    foreach ( $posts as $p ) {
        $post_type_label = ( 'post' === $p->post_type ) ? __( 'Post', 'custom-theme' ) : __( 'Page', 'custom-theme' );
        $selected = ( $selected_post_id_1 == $p->ID ) ? 'selected="selected"' : '';
        echo '<option value="' . esc_attr( $p->ID ) . '" ' . $selected . '>' . esc_html( $p->post_title ) . ' (' . esc_html( $post_type_label ) . ')</option>';
    }
    echo '</select>';
    echo '</div>';
    // Fields for internal linking (Internal)
    echo '<div id="internal_link_1_fields" class="' . ( 'external' === $button_type_1 ? 'hidden' : '' ) . '" style="display: inline-block;">';
    echo '<label for="slider_external_url_1" style="margin-right: 10px;">' . __( 'External URL:', 'custom-theme' ) . '</label>';
    echo '<input type="text" id="slider_external_url_1" name="slider_external_url_1" value="' . esc_attr( $external_url_1 ) . '" class="widefat" style="width: 100%;"/>';
    echo '</div>';
    echo '<div id="slider_button_text_1_field" style="display: inline-block;">';
    echo '<label for="slider_button_text_1" style="margin-right: 10px;">' . __( 'Button Text:', 'custom-theme' ) . '</label>';
    echo '<input type="text" id="slider_button_text_1" name="slider_button_text_1" value="' . esc_attr( $button_text_1 ) . '" style="width: auto; display: inline-block;" class="widefat" />';
    echo '</div>';
    // Checkbox to open in a new tab
    echo '<div id="slider_open_in_new_tab_1_field" style="display: inline-block;">';
    echo '<label for="slider_open_in_new_tab_1">';
    echo '<input type="checkbox" id="slider_open_in_new_tab_1" name="slider_open_in_new_tab_1" ' . checked( $open_in_new_tab_1, 'on', false ) . ' /> ';
    echo __( 'Open link in new tab', 'custom-theme' );
    echo '</label>';
    echo '</div>';
    echo '</div>';
    // Fields for the second button
    echo '<div class="slider-button-fields" style="display: inline-flex; align-items: center; flex-wrap: wrap; gap: 10px; margin-top: 10px;">';
    echo '<label for="slider_button_type_2">' . __( 'Button Type (Button 2):', 'custom-theme' ) . '</label>';
    echo '<select id="slider_button_type_2" name="slider_button_type_2" style="width: auto; display: inline-block;">
            <option value="internal" ' . selected( $button_type_2, 'internal', false ) . '>' . __( 'Internal', 'custom-theme' ) . '</option>
            <option value="external" ' . selected( $button_type_2, 'external', false ) . '>' . __( 'External', 'custom-theme' ) . '</option>
        </select>';
    // External Link Fields (External)
    echo '<div id="external_link_2_fields" class="' . ( 'internal' === $button_type_2 ? 'hidden' : '' ) . '" style="display: inline-block;">';
    echo '<label for="slider_related_post_2" style="margin-right: 10px;">' . __( 'Select a post or page:', 'custom-theme' ) . '</label>';
    echo '<select id="slider_related_post_2" name="slider_related_post_2" style="width: 100%;">';
    echo '<option value="">' . __( 'None', 'custom-theme' ) . '</option>';
    foreach ( $posts as $p ) {
        $post_type_label = ( 'post' === $p->post_type ) ? __( 'Post', 'custom-theme' ) : __( 'Page', 'custom-theme' );
        $selected = ( $selected_post_id_2 == $p->ID ) ? 'selected="selected"' : '';
        echo '<option value="' . esc_attr( $p->ID ) . '" ' . $selected . '>' . esc_html( $p->post_title ) . ' (' . esc_html( $post_type_label ) . ')</option>';
    }
    echo '</select>';
    echo '</div>';
    // Fields for internal linking (External)
    echo '<div id="internal_link_2_fields" class="' . ( 'internal' === $button_type_2 ? 'hidden' : '' ) . '" style="display: inline-block;">';
    echo '<label for="slider_external_url_2" style="margin-right: 10px;">' . __( 'External URL:', 'custom-theme' ) . '</label>';
    echo '<input type="text" id="slider_external_url_2" name="slider_external_url_2" value="' . esc_attr( $external_url_2 ) . '" class="widefat" style="width: 100%;"/>';
    echo '</div>';
    echo '<div id="slider_button_text_2_field" style="display: inline-block;">';
    echo '<label for="slider_button_text_2" style="margin-right: 10px;">' . __( 'Button Text:', 'custom-theme' ) . '</label>';
    echo '<input type="text" id="slider_button_text_2" name="slider_button_text_2" value="' . esc_attr( $button_text_2 ) . '" style="width: auto; display: inline-block;" class="widefat" />';
    echo '</div>';
    // Checkbox to open in a new tab
    echo '<div id="slider_open_in_new_tab_2_field" style="display: inline-block;">';
    echo '<label for="slider_open_in_new_tab_2">';
    echo '<input type="checkbox" id="slider_open_in_new_tab_2" name="slider_open_in_new_tab_2" ' . checked( $open_in_new_tab_2, 'on', false ) . ' /> ';
    echo __( 'Open link in new tab', 'custom-theme' );
    echo '</label>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    // Enqueue Select2 Scripts and Styles
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    // Initialize select2 for search functionality
    jQuery('#slider_related_post_1, #slider_related_post_2').select2({
        placeholder: '<?php esc_attr_e( 'Search for a post or page', 'custom-theme' ); ?>',
        allowClear: true,
    });

        // Function for displaying hidden fields based on button type
        function toggleFields() {
            // Button 1 toggle
            let buttonType1 = document.getElementById('slider_button_type_1').value;
            let internalLink1 = document.getElementById('internal_link_1_fields');
            let externalLink1 = document.getElementById('external_link_1_fields');
            let buttonText1 = document.getElementById('slider_button_text_1_field');

            if (buttonType1 === 'external') {
                internalLink1.style.display = 'inline-block';
                externalLink1.style.display = 'none';
            } else {
                internalLink1.style.display = 'none';
                externalLink1.style.display = 'inline-block';
            }
            buttonText1.style.display = 'inline-block'; // Button text field is always shown

            // Button 2 toggle
            let buttonType2 = document.getElementById('slider_button_type_2').value;
            let internalLink2 = document.getElementById('internal_link_2_fields');
            let externalLink2 = document.getElementById('external_link_2_fields');
            let buttonText2 = document.getElementById('slider_button_text_2_field');

            if (buttonType2 === 'external') {
                internalLink2.style.display = 'inline-block';
                externalLink2.style.display = 'none';
            } else {
                internalLink2.style.display = 'none';
                externalLink2.style.display = 'inline-block';
            }
            buttonText2.style.display = 'inline-block'; // Button text field is always shown
        }

        // Listen for changes in the select field
        document.getElementById('slider_button_type_1').addEventListener('change', toggleFields);
        document.getElementById('slider_button_type_2').addEventListener('change', toggleFields);

        // Apply initial settings
        toggleFields();
    });
    </script>
<?php }

// Saving metabox data
add_action( 'save_post', 'save_slider_meta_box' );

function save_slider_meta_box( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return $post_id;
    }
    if ( isset( $_POST['slider_button_type_1'] ) ) {
        update_post_meta( $post_id, '_slider_button_type_1', sanitize_text_field( $_POST['slider_button_type_1'] ) );
    }
    if ( isset( $_POST['slider_external_url_1'] ) ) {
        update_post_meta( $post_id, '_slider_external_url_1', sanitize_text_field( $_POST['slider_external_url_1'] ) );
    }
    if ( isset( $_POST['slider_related_post_1'] ) ) {
        update_post_meta( $post_id, '_slider_related_post_1', sanitize_text_field( $_POST['slider_related_post_1'] ) );
    }
    if ( isset( $_POST['slider_button_text_1'] ) ) {
        update_post_meta( $post_id, '_slider_button_text_1', sanitize_text_field( $_POST['slider_button_text_1'] ) );
    }
    if ( isset( $_POST['slider_open_in_new_tab_1'] ) ) {
        update_post_meta( $post_id, '_slider_open_in_new_tab_1', 'on' );
    } else {
        update_post_meta( $post_id, '_slider_open_in_new_tab_1', '' );
    }
    if ( isset( $_POST['slider_button_type_2'] ) ) {
        update_post_meta( $post_id, '_slider_button_type_2', sanitize_text_field( $_POST['slider_button_type_2'] ) );
    }
    if ( isset( $_POST['slider_external_url_2'] ) ) {
        update_post_meta( $post_id, '_slider_external_url_2', sanitize_text_field( $_POST['slider_external_url_2'] ) );
    }
    if ( isset( $_POST['slider_related_post_2'] ) ) {
        update_post_meta( $post_id, '_slider_related_post_2', sanitize_text_field( $_POST['slider_related_post_2'] ) );
    }
    if ( isset( $_POST['slider_button_text_2'] ) ) {
        update_post_meta( $post_id, '_slider_button_text_2', sanitize_text_field( $_POST['slider_button_text_2'] ) );
    }
    if ( isset( $_POST['slider_open_in_new_tab_2'] ) ) {
        update_post_meta( $post_id, '_slider_open_in_new_tab_2', 'on' );
    } else {
        update_post_meta( $post_id, '_slider_open_in_new_tab_2', '' );
    }
}