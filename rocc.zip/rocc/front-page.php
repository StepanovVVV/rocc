<?php
/*
Template Name: Front page
*/
get_header(); ?>

<main class="main-wrapper main-top">

    <!-- Function to display home slider -->
    <?php custom_display_slider(); ?>
    <!-- Function to display home slider -->

    <?php 
        $products_title = CFS()->get('products_title');
        $fields = CFS()->get('products_list');

        if ( is_null( $fields ) ) {
            $fields = array();
        }

        $valid_products = array_filter($fields, function($field) {
            return !empty($field['title']) || !empty($field['image']);
        });

        if ( !empty( $products_title ) || !empty( $valid_products ) ) :
        ?>
    <section class="products" id="refreshing">
        <?php if ( !empty( $products_title ) ) : ?>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <h2 class="products__title title"><?php echo esc_html( $products_title ); ?></h2>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if ( !empty( $valid_products ) ) : ?>
        <div class="products__container grid-container">
            <div class="grid-x grid-padding-x">
                <?php 
                    foreach ( $valid_products as $field ) : 
                        $title = isset( $field['title'] ) ? $field['title'] : '';
                        $image = isset( $field['image'] ) ? $field['image'] : '';
                        $alt = get_post_meta( $image, '_wp_attachment_image_alt', true );
                    ?>
                <div class="cell small-12 medium-6 large-3">
                    <div class="products__wrap">
                        <div class="products__img">
                            <?php if ( !empty( $image ) ) : ?>
                            <img src="<?php echo esc_url( wp_get_attachment_url( $image ) ); ?>"
                                alt="<?php echo esc_attr( $alt ); ?>">
                            <?php endif; ?>
                        </div>
                        <?php if ( !empty( $title ) ) : ?>
                        <h2 class="products__name"><?php echo esc_html( $title ); ?></h2>
                        <?php endif; ?>
                    </div>
                </div>
                <?php 
                    endforeach; 
                    ?>
            </div>
        </div>
        <?php endif; ?>
    </section>
    <?php 
        endif;
    ?>

    <?php 
        $functions_title = CFS()->get('functions_title');
        $functions_list = CFS()->get('functions_list');

        if (is_null($functions_list)) {
            $functions_list = array();
        }

        $valid_functions = array_filter($functions_list, function($function) {
            return !empty($function['function_name']) || !empty($function['function_image']);
        });

        if (!empty($functions_title) || !empty($valid_functions)) : ?>
    <section class="works" id="works">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <?php if (!empty($functions_title)) : ?>
                    <h2 class="works__title title"><?php echo esc_html($functions_title); ?></h2>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if (!empty($valid_functions)) : ?>
        <div class="works__tabs tabs">
            <div class="works__container grid-container">
                <div class="grid-x grid-padding-x">
                    <div class="cell small-12 medium-12 large-4">
                        <div class="tabs__btns">
                            <?php
                                $i = 0;
                                foreach ($valid_functions as $function):
                                    $active_class = ($i === 0) ? 'active' : '';
                                    $function_name = isset($function['function_name']) ? $function['function_name'] : '';
                                ?>
                            <?php if (!empty($function_name)) : ?>
                            <div class="tabs__btn <?php echo $active_class; ?>">
                                <button><?php echo esc_html($function_name); ?></button>
                            </div>
                            <?php endif; ?>
                            <?php
                                $i++;
                            endforeach;
                            ?>
                        </div>
                    </div>
                    <div class="cell small-12 medium-12 large-8">
                        <div class="tabs__items">
                            <?php
                                $i = 0;
                                foreach ($valid_functions as $function):
                                    $active_class = ($i === 0) ? 'active' : '';
                                    $function_info = isset($function['function_info']) ? $function['function_info'] : '';
                                    $image_id = isset($function['function_image']) ? $function['function_image'] : '';
                                    
                                    if (!empty($image_id)) {
                                        $image_url = wp_get_attachment_image_src($image_id, 'full')[0];
                                        $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
                                    }
                                ?>
                            <div class="tabs__item <?php echo $active_class; ?>">
                                <?php if (!empty($function_info)) : ?>
                                <div class="tabs__info">
                                    <?php echo esc_html($function_info); ?>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($image_id)) : ?>
                                <div class="tabs__img">
                                    <img src="<?php echo esc_url($image_url); ?>"
                                        alt="<?php echo esc_attr($image_alt); ?>">
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php
                                $i++;
                            endforeach;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>

    <?php 
    $image_id = CFS()->get('full_image'); 
    $title = CFS()->get('scroll_text');

    if ( !empty( $image_id ) || !empty( $title ) ) :
        $alt = '';
        if ( !empty( $image_id ) ) {
            $alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
        }
        ?>
    <section class="full-box">
        <div class="full-box__container">
            <?php if ( !empty( $image_id ) ) : ?>
            <div class="full-box__img">
                <img src="<?php echo esc_url( wp_get_attachment_url( $image_id ) ); ?>"
                    alt="<?php echo esc_attr( !empty( $alt ) ? $alt : '' ); ?>">
            </div>
            <?php endif; ?>
            <?php if ( !empty( $title ) ) : ?>
            <div class="full-box__wrap" style='overflow:hidden'>
                <h2 class="full-box__title"><?php echo esc_html( $title ); ?></h2>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php 
        $conscious_list = CFS()->get('conscious_list');
    
        if (!empty($conscious_list)) :
            foreach ($conscious_list as $conscious_item) :
                $conscious_image = isset($conscious_item['conscious_image']) ? $conscious_item['conscious_image'] : '';
                $conscious_info = isset($conscious_item['conscious_info']) ? $conscious_item['conscious_info'] : '';
                $conscious_right_image = isset($conscious_item['conscious_right_image']) ? $conscious_item['conscious_right_image'] : false;
                $grid_class = $conscious_right_image ? 'grid-x-row-r' : '';
    ?>
    <section class="eco-smile" id="conscious">
        <div class="eco-smile__container box">
            <div class="grid-x <?php echo esc_attr($grid_class); ?>">
                <?php if (!empty($conscious_image)) :
                $conscious_image_url = wp_get_attachment_image_src($conscious_image, 'full')[0];
                $conscious_image_alt = get_post_meta($conscious_image, '_wp_attachment_image_alt', true);
            ?>
                <div class="cell small-12 medium-6 large-6">
                    <div class="box__wrap">
                        <div class="box__image">
                            <img src="<?php echo esc_url($conscious_image_url); ?>"
                                alt="<?php echo esc_attr($conscious_image_alt); ?>">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if (!empty($conscious_info)) : ?>
                <div class="cell small-12 medium-6 large-6">
                    <div class="box__wrap">
                        <div class="box__info">
                            <?php echo wp_kses_post($conscious_info); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
        <?php 
        endforeach;
    endif; 
    ?>

    <?php 
        $values_title = CFS()->get('values_title');
        $values_list = CFS()->get('values_list'); 

        if ( !empty($values_title) || !empty($values_list) ) :
            $valid_values = array_filter($values_list, function($value) {
                return !empty($value['value_icon']) || !empty($value['value_name']);
            });

            if ( !empty($valid_values) ) :
    ?>
    <section class="why-us" id="values">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <?php if (!empty($values_title)) : ?>
                    <h2 class="why-us__title title">
                        <?php echo esc_html($values_title); ?>
                    </h2>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="why-us__container grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell why-us__cell">
                    <?php foreach ($valid_values as $value) :
                    $value_icon_id = isset($value['value_icon']) ? $value['value_icon'] : '';
                    $value_name = isset($value['value_name']) ? $value['value_name'] : '';

                    if (!empty($value_icon_id)) {
                        $value_icon_url = wp_get_attachment_image_src($value_icon_id, 'full')[0];
                        $value_icon_alt = get_post_meta($value_icon_id, '_wp_attachment_image_alt', true);
                    }
                ?>
                    <div class="why-us__wrap">
                        <?php if (!empty($value_icon_id)) : ?>
                        <div class="why-us__icon">
                            <img src="<?php echo esc_url($value_icon_url); ?>"
                                alt="<?php echo esc_attr($value_icon_alt); ?>">
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($value_name)) : ?>
                        <h4 class="why-us__name"><?php echo esc_html($value_name); ?></h4>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>
    <?php 
        endif; 
    endif; 
    ?>
    
    <?php
        $details_title = CFS()->get('details_title');
        $details_button = CFS()->get('details_button');
        $details_image_id = CFS()->get('details_image');

        if (!empty($details_title) || !empty($details_button) || !empty($details_image_id)) : 
    ?>
    <section class="get">
        <div class="get__container grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell medium-12 large-6">
                    <div class="get__wrap">
                        <div class="get__box">
                            <?php if (!empty($details_title)) : ?>
                                <h2 class="get__title">
                                    <?php echo esc_html($details_title); ?>
                                </h2>
                            <?php endif; ?>
                            <?php if (!empty($details_button) && isset($details_button['url'], $details_button['text'])) : ?>
                                <div class="get__btn btn">
                                    <a href="<?php echo esc_url($details_button['url']); ?>" class="btn__wrap" data-fancybox><?php echo esc_html($details_button['text']); ?></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php if (!empty($details_image_id)) :
                    $image_url = wp_get_attachment_image_url($details_image_id, 'full');
                    if ($image_url) : 
                        $image_alt = get_post_meta($details_image_id, '_wp_attachment_image_alt', true); 
                        ?>
                <div class="cell medium-12 large-9">
                    <div class="get__wrap">
                        <div class="get__img">
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt ? $image_alt : 'Image'); ?>">
                        </div> 
                    </div>
                </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php
        endif;
    ?>

    <?php
        $reviews = CFS()->get('reviews_list'); 
        if (!empty($reviews)) : 
            $has_content = false;
            ?>
        <section class="reviews" id="reviews">
            <div class="reviews__container grid-container">
                <div class="grid-x grid-padding-x reviews__slider">
                    <?php foreach ($reviews as $review) : 
                        $has_star = !empty($review['reviews_star']);
                        $has_name = !empty($review['reviews_name']);
                        $has_text = !empty($review['reviews_text']);
                        if ($has_star || $has_name || $has_text) :
                            $has_content = true; 
                        ?>
                            <div class="cell">
                                <div class="reviews__wrap">
                                    <?php if ($has_star) : ?>
                                        <div class="star">
                                            <?php echo esc_html(implode(' ', $review['reviews_star'])); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($has_name) : ?>
                                        <h3 class="reviews__name">
                                            <?php echo esc_html($review['reviews_name']); ?>
                                        </h3>
                                    <?php endif; ?>
                                    <?php if ($has_text) : ?>
                                        <p class="reviews__text">
                                            <?php echo esc_html($review['reviews_text']); ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
        endif;
    ?>

<?php 
    $faq_title = CFS()->get('faq_title');
    $faq_list = CFS()->get('faq_list');

    if (!empty($faq_title) || !empty($faq_list)) :
        $valid_faq = array_filter($faq_list, function($faq) {
            return !empty($faq['faq_name']) || !empty($faq['faq_text']);
        });

        if (!empty($valid_faq)) : 
    ?>
    <section class="faq" id="faq">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell small-12 medium-12 large-12">
                    <div class="faq__wrap">
                        <?php if (!empty($faq_title)) : ?>
                            <h2 class="faq__title title"><?php echo esc_html($faq_title); ?></h2>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="grid-container faq__container">
            <div class="grid-x grid-padding-x">
                <div class="cell small-12 medium-12 large-12">
                    <div class="faq__wrapper">
                        <div class="accordion">
                            <div class="accordion__container">
                                <?php 
                                foreach ($valid_faq as $faq) :
                                    $faq_icon_id = CFS()->get('faq_icon'); 
                                    if ($faq_icon_id) {
                                        $faq_icon_url = wp_get_attachment_image_url($faq_icon_id, 'full');
                                        $faq_icon_alt = get_post_meta($faq_icon_id, '_wp_attachment_image_alt', true);
                                    }
                                ?>
                                    <div class="accordion__wrap">
                                        <?php if (!empty($faq['faq_name'])) : ?>
                                            <div class="accordion__title">
                                                <h3 class="accordion__title-wrap">
                                                    <?php echo esc_html($faq['faq_name']); ?>
                                                </h3>
                                                <?php if ($faq_icon_id) : ?>
                                                    <div class="accordion__icon">
                                                        <img src="<?php echo esc_url($faq_icon_url); ?>" alt="<?php echo esc_attr($faq_icon_alt); ?>">
                                                    </div>
                                                <?php else : ?>
                                                    <div class="accordion__icon">
                                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/image/icons/plus.svg" alt="plus">
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($faq['faq_text'])) : ?>
                                            <div class="accordion__info">
                                                <p class="accordion__text">
                                                    <?php echo esc_html($faq['faq_text']); ?>
                                                </p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php 
        endif; 
    endif;
?>

    <section class="connect" id="contact">
        <div class="connect__container">
            <div class="grid-x">
            <?php 
                $images = CFS()->get('connect_image_left'); 

                if (!empty($images) && is_array($images)) : ?>
                    <div class="cell small-12 medium-6 large-6">
                        <div class="grid-x">
                            <?php foreach ($images as $image) : 
                                $large_width = isset($image['connect_image_width_1']) && is_array($image['connect_image_width_1']) ? key($image['connect_image_width_1']) : 6;
                                $img_id = isset($image['connect_image_1']) ? $image['connect_image_1'] : null;
                                $img_url = $img_id ? wp_get_attachment_image_src($img_id, 'full') : null;
                                $img_url = $img_url ? $img_url[0] : '';
                                $img_alt = !empty($image['connect_image_alt_1']) ? esc_attr($image['connect_image_alt_1']) : get_post_meta($img_id, '_wp_attachment_image_alt', true);
                                $img_alt = !empty($img_alt) ? $img_alt : 'Image';
                            ?>
                                <?php if ($img_url): ?>
                                    <div class="cell medium-<?php echo $large_width; ?> large-<?php echo $large_width; ?>">
                                        <div class="connect__wrap">
                                            <div class="connect__img">
                                                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($img_alt); ?>">
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="cell connect__cell">
                    <?php
                        echo CFS()->get( 'connect_info' ); 
                    ?>
                </div>
                <?php 
                    $images_right = CFS()->get('connect_image_right');

                    if (!empty($images_right) && is_array($images_right)) : ?>
                        <div class="cell small-12 medium-6 large-6">
                            <div class="grid-x">
                                <?php foreach ($images_right as $image_right) : 
                                    $large_width_right = isset($image_right['connect_image_width_2']) && is_array($image_right['connect_image_width_2']) ? key($image_right['connect_image_width_2']) : 6;
                                    $img_id_right = isset($image_right['connect_image_2']) ? $image_right['connect_image_2'] : null;
                                    $img_url_right = $img_id_right ? wp_get_attachment_image_src($img_id_right, 'full') : null;
                                    $img_url_right = $img_url_right ? $img_url_right[0] : '';
                                    $img_alt_right = !empty($image_right['connect_image_alt_2']) ? esc_attr($image_right['connect_image_alt_2']) : get_post_meta($img_id_right, '_wp_attachment_image_alt', true);
                                    $img_alt_right = !empty($img_alt_right) ? $img_alt_right : 'Image';
                                ?>
                                    <?php if ($img_url_right): ?>
                                        <div class="cell medium-<?php echo $large_width_right; ?> large-<?php echo $large_width_right; ?>">
                                            <div class="connect__wrap">
                                                <div class="connect__img">
                                                    <img src="<?php echo esc_url($img_url_right); ?>" alt="<?php echo esc_attr($img_alt_right); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
            </div>
        </div>
    </section>
</main>

<?php the_content(); ?>

<?php get_footer(); ?>