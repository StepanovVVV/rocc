<?php
// Сonnection styles and scripts
function custom_enqueue_select() {
    // Connecting styles and scripts
    wp_enqueue_style('select2-css', get_template_directory_uri() . '/assets/css/plugins/select2.min.css', array(), '4.0.13');
    wp_enqueue_script('select2-js', get_template_directory_uri() . '/assets/js/plugins/select2.min.js', array('jquery'), '4.0.13', true);

    if (!is_admin()) {
        // Additional styles and scripts for the frontend
        wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap', array(), null);
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
        // wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/plugins/font-awesome.min.css');
        wp_enqueue_style('fancybox', get_template_directory_uri() . '/assets/css/plugins/fancybox.min.css');
        wp_enqueue_style('style', get_template_directory_uri() . '/assets/css/style.min.css', array(), '1.0.0');

        wp_deregister_script('jquery');
        wp_register_script('jquery', get_template_directory_uri() . '/assets/js/plugins/jquery-3.6.0.js', array(), '3.6.0', true);
        wp_enqueue_script('jquery');
        wp_enqueue_script('wp-link');
        wp_enqueue_script('lazyload', get_template_directory_uri() . '/assets/js/plugins/lazyload.min.js', array(), '1.0.0', true);
        wp_enqueue_script('marquee', get_template_directory_uri() . '/assets/js/plugins/jquery.marquee.min.js', array(), '1.0.0', true);
        wp_enqueue_script('fancybox', get_template_directory_uri() . '/assets/js/plugins/fancybox.min.js', array('jquery'), '3.5.7', true);
        wp_enqueue_script('slick-slider', get_template_directory_uri() . '/assets/js/plugins/slick.min.js', array('jquery'), '1.8.1', true);
        wp_enqueue_script('phones-mask', get_template_directory_uri() . '/assets/js/plugins/phones-mask.js', array('jquery'), '1.0.0', true);
        wp_enqueue_script('jarallax', get_template_directory_uri() . '/assets/js/plugins/jarallax.min.js', array('jquery'), '1.0.0', true);
        wp_enqueue_script('script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '1.0.0', true);

        // Passing variables for Ajax requests
        wp_localize_script('script', 'ajax', array(
            'url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('load_more_nonce')
        ));
    }

    if ((is_page(array('contacts')))) {
        wp_enqueue_script('google-map', get_template_directory_uri() . '/assets/js/plugins/map.js', array('jquery'), '', true);
    }
}
add_action('wp_enqueue_scripts', 'custom_enqueue_select');
add_action('admin_enqueue_scripts', 'custom_enqueue_select');

// Сonnecting other files
require_once get_template_directory() . '/incs/class-starter-navigation.php';
require_once get_template_directory() . '/incs/class-start-comment.php';
require_once get_template_directory() . '/incs/customizer.php';
require_once get_template_directory() . '/incs/home-slider-meta-box.php';
require_once get_template_directory() . '/parts/home-slider.php';
require_once get_template_directory() . '/incs/contact-form-shortcode.php';

// Adding support for loading JSON files into ACF
add_filter('acf/settings/load_json', function($paths) {
    $paths[] = get_template_directory() . '/acf-json';
    return $paths;
});

// Adding a field Theme Settings for ACF PRO
if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title'    => __('Theme Settings', 'testdomain'),
        'menu_title'    => __('Theme Settings', 'testdomain'),
        'menu_slug'     => __('theme-settings', 'testdomain'),
        'capability'    => __('edit_theme_options', 'testdomain'),
        'redirect'      => false
    ));
}

// Permission to add these types of files to the media library.
add_filter( 'upload_mimes', 'upload_allow_types' );
function upload_allow_types( $mimes ) {

	$mimes['ico']  = 'image/vnd.microsoft.icon';
    $mimes['svg'] = 'image/svg+xml';

	return $mimes;
}

// Add need classes for body
function custom_body_classes( $classes ) {
    $classes[] = 'hidden';
    $classes[] = 'body-wrapper';

    return $classes;
}

add_filter( 'body_class', 'custom_body_classes' );

// Remove author archive pages
function remove_author_archive_page() {
	global $wp_query;

	if ( is_author() ) {
		$wp_query->set_404();
		status_header( 404 );
		// Redirect to homepage
		// wp_redirect(get_option('home'));
	}
}

// Fotmats for WYSIWYG Editor
function custom_style_selector($buttons) {
    array_unshift($buttons, 'styleselect');
    return $buttons;
}

add_filter('mce_buttons_2', 'custom_style_selector');

function starter_update_default_tinymce_settings($init_array)
{
    $style_formats = array(
        array(
            'title' => 'Heading 1',
            'classes' => 'h1',
            'selector' => 'h1,h2,h3,h4,h5,h6,p,li',
            'wrapper' => false,
        ),
        array(
            'title' => 'Heading 2',
            'classes' => 'h2',
            'selector' => 'h1,h2,h3,h4,h5,h6,p,li',
            'wrapper' => false,
        ),
        array(
            'title' => 'Heading 3',
            'classes' => 'h3',
            'selector' => 'h1,h2,h3,h4,h5,h6,p,li',
            'wrapper' => false,
        ),
        array(
            'title' => 'Heading 4',
            'classes' => 'h4',
            'selector' => 'h1,h2,h3,h4,h5,h6,p,li',
            'wrapper' => false,
        ),
        array(
            'title' => 'Heading 5',
            'classes' => 'h5',
            'selector' => 'h1,h2,h3,h4,h5,h6,p,li',
            'wrapper' => false,
        ),
        array(
            'title' => 'Heading 6',
            'classes' => 'h6',
            'selector' => 'h1,h2,h3,h4,h5,h6,p,li',
            'wrapper' => false,
        ),
        array(
            'title' => 'Button',
            'classes' => 'button',
            'selector' => 'a',
            'wrapper' => false,
        ),
        array(
            'title' => 'Small text',
            'inline' => 'small',
        ),
        array(
            'title' => 'Two columns',
            'classes' => 'two-columns',
            'selector' => 'p,h1,h2,h3,h4,h5,h6,ul',
        ),
        array(
            'title' => 'Three columns',
            'classes' => 'three-columns',
            'selector' => 'p,h1,h2,h3,h4,h5,h6,ul',
        ),
    );
    $init_array['style_formats'] = json_encode($style_formats);
    $editor_style_path = get_stylesheet_directory() . '/editor-style.css';

    if (file_exists($editor_style_path)) {
        $time = filemtime($editor_style_path);
        $init_array['cache_suffix'] = 'v=' . $time;
    } else {
        $init_array['cache_suffix'] = 'v=1'; 
    }
    
    $default_colours = '"000000", "Black","993300", "Burnt orange","333300", "Dark olive","003300", "Dark green","003366", "Dark azure","000080", "Navy Blue","333399", "Indigo","333333", "Very dark gray","800000", "Maroon","FF6600", "Orange","808000", "Olive","008000", "Green","008080", "Teal","0000FF", "Blue","666699", "Grayish blue","808080", "Gray","FF0000", "Red","FF9900", "Amber","99CC00", "Yellow green","339966", "Sea green","33CCCC", "Turquoise","3366FF", "Royal blue","800080", "Purple","999999", "Medium gray","FF00FF", "Magenta","FFCC00", "Gold","FFFF00", "Yellow","00FF00", "Lime","00FFFF", "Aqua","00CCFF", "Sky blue","993366", "Brown","C0C0C0", "Silver","FF99CC", "Pink","FFCC99", "Peach","FFFF99", "Light yellow","CCFFCC", "Pale green","CCFFFF", "Pale cyan","99CCFF", "Light sky blue","CC99FF", "Plum","FFFFFF", "White"';
    $custom_colours = '';
    
    foreach (get_theme_colors() as $color) {
        $custom_colours .= '"' . str_replace('#', '', $color['color']) . '","' . $color['name'] . '",';
    }
    
    $init_array['textcolor_map'] = '[' . $default_colours . ',' . $custom_colours . ']';
    $init_array['textcolor_rows'] = 6;
    
    return $init_array;
}

add_filter('tiny_mce_before_init', 'starter_update_default_tinymce_settings');
add_editor_style();

/**
 * Theme main colors.
 *
 * @return array
 */
function get_theme_colors() {
	// Default colors fallback.
	// TODO Fill $palette array with main design colors to be able use in Gutenberg editor 
	$palette = [
		[ "name" => "Black", "slug" => "black", "color" => "#000000" ],
		[ "name" => "White", "slug" => "white", "color" => "#ffffff" ],
		[ "name" => "Blue", "slug" => "blue", "color" => "#2d22b4" ],
	];

	return $palette;
}

add_action( 'template_redirect', 'remove_author_archive_page' );

// For Google-map API
function pass_custom_data_to_js() {
    // Get data from the Customizer
    $custom_address = get_theme_mod('custom_address', ''); // Address from the Customizer
    $site_title = get_bloginfo('name'); // Site title
    $google_maps_api_key = get_theme_mod('google_maps_api_key', ''); // Get API key
    
    // Pass data to JavaScript
    wp_localize_script('google-map', 'mapData', array(
        'address' => !empty($custom_address) ? $custom_address : 'Default Address', // Ensure there is an address
        'title'   => !empty($site_title) ? $site_title : 'Default Title', // Ensure there is a site title
        'api_key' => !empty($google_maps_api_key) ? $google_maps_api_key : '', // Ensure there is an API key
    ));
}
add_action('wp_enqueue_scripts', 'pass_custom_data_to_js');

// Add for form submission
function register_form_submission_post_type() {
    $labels = array(
        'name'               => __('Form Submissions', 'testdomain'),
        'singular_name'      => __('Form Submission', 'testdomain'),
        'menu_name'          => __('Form Submissions', 'testdomain'),
        'name_admin_bar'     => __('Form Submission', 'testdomain'),
        'add_new'            => __('Add New', 'testdomain'),
        'add_new_item'       => __('Add New Submission', 'testdomain'),
        'new_item'           => __('New Submission', 'testdomain'),
        'edit_item'          => __('Edit Submission', 'testdomain'),
        'view_item'          => __('View Submission', 'testdomain'),
        'all_items'          => __('All Submissions', 'testdomain'),
        'search_items'       => __('Search Submissions', 'testdomain'),
        'not_found'          => __('No submissions found.', 'testdomain'),
        'not_found_in_trash' => __('No submissions found in Trash.', 'testdomain'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'form_submission'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array('title', 'editor', 'custom-fields'),
        'show_in_rest'       => true, 
        'menu_icon' => 'dashicons-email',
        'exclude_from_search'=> true,
    );

    register_post_type('form_submission', $args);
}
add_action('init', 'register_form_submission_post_type');

// Start or page COMMENTS
// Rename button for page "Reviews"
function custom_comment_navigation_text($translated_text, $text, $domain) {
    if ('Newer comments' === $text) {
        $translated_text = __('Next', 'custom-theme');
    }

    if ('Older comments' === $text) {
        $translated_text = __('Previous', 'custom-theme');
    }

    return $translated_text;
}
add_filter('gettext', 'custom_comment_navigation_text', 20, 3);

function save_comment_rating( $comment_id ) {
    if ( isset( $_POST['rating'] ) ) {
        $rating = intval( $_POST['rating'] );
        if ( $rating > 0 && $rating <= 5 ) {
            add_comment_meta( $comment_id, 'rating', $rating, true );
        }
    }
}
add_action( 'comment_post', 'save_comment_rating' );

function add_rating_column_to_comments( $columns ) {
    $columns['rating'] = 'Rating';
    return $columns;
}
add_filter( 'manage_edit-comments_columns', 'add_rating_column_to_comments' );

function display_rating_column_in_comments( $column, $comment_id ) {
    if ( 'rating' === $column ) {
        $rating = get_comment_meta( $comment_id, 'rating', true );
        if ( ! empty( $rating ) ) {
            for ( $i = 1; $i <= 5; $i++ ) {
                echo ( $i <= $rating ) ? '★' : '☆';
            }
        } else {
            echo 'No rating';
        }
    }
}
add_action( 'manage_comments_custom_column', 'display_rating_column_in_comments', 10, 2 );

function custom_redirect_after_comment($location) {
    return $_SERVER["HTTP_REFERER"] . "#comments";
}
add_filter('comment_post_redirect', 'custom_redirect_after_comment');

// Sorting comments on a page Reviews new->old
function custom_comment_order( $query ) {
    if ( is_page( 'reviews' ) ) {
        $query->query_vars['orderby'] = 'comment_date';
        $query->query_vars['order'] = 'DESC';
        $query->query_vars['paged'] = get_query_var( 'cpage' ) ? get_query_var( 'cpage' ) : 1;
    }
}
add_action( 'pre_get_comments', 'custom_comment_order' );
// End for page COMMENTS

// Sidebar
function custom_theme_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'custom-theme' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'custom-theme' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'custom_theme_widgets_init' );

// Add new functions
add_action('after_setup_theme', function () {
    //    load_theme_textdomain('testdomain', get_template_directory() . '/languages');

    // Title for all pages
    add_theme_support( 'title-tag' );

    // Add image in posts (thumbnails)
    add_theme_support( 'post-thumbnails' );

    // Add custom logo
    add_theme_support( 'custom-logo' );

    // Disable Gutenberg
    add_filter('use_block_editor_for_post', '__return_false', 10);

    // For HTML5
    add_theme_support( 'html5', array(
        'comment-list',
        'comment-form',
        'search-form',
        'gallery',
        'caption',
        'script',
        'style',
    ));

    // Register menus
    register_nav_menus(
        array(
            'header-menu' => __('Header menu', 'testdomain'),
        )
    );
});
