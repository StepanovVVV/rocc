<?php
$socials = CFS()->get('socials');

if (!empty($socials)) {
    $saved_socials = get_option('global_socials');

    if ($saved_socials !== $socials) {
        update_option('global_socials', $socials);
    }
}
?>

<?php
$socials = get_option('global_socials');

if (!empty($socials)): ?>
    <ul class="socials">
        <?php foreach ($socials as $social):
            $social_network_keys = array_keys($social['social_network']);
            $social_network_key = $social_network_keys[0];
            $social_network_label = $social['social_network'][$social_network_key]; 
            $social_profile_url = isset($social['social_profile']['url']) ? $social['social_profile']['url'] : '';

            if (!empty($social_network_label) && !empty($social_profile_url)): ?>
                <li class="socials__item">
                    <a class="socials__link"
                       href="<?php echo esc_url($social_profile_url); ?>"
                       target="_blank"
                       aria-label="<?php echo esc_attr($social_network_label); ?>"
                       rel="noopener">
                       <span aria-hidden="true" class="socials__icon fab fa-<?php echo esc_attr($social_network_key); ?>"></span>
                    </a>
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>No social profiles found.</p>
<?php endif; ?>
